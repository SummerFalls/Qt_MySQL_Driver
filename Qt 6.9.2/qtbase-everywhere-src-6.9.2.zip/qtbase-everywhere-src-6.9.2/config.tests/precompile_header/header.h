// Copyright (C) 2021 The Qt Company Ltd.
// SPDX-License-Identifier: BSD-3-Clause
#ifndef HEADER_H
#define HEADER_H

// Nothing to see here. We just want the HEADER_H define.

#endif
