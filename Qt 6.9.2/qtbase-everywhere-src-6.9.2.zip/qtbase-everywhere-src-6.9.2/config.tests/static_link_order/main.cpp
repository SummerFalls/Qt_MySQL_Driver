// Copyright (C) 2021 The Qt Company Ltd.
// SPDX-License-Identifier: BSD-3-Clause

void staticLibFunc1();

int main() {
    staticLibFunc1();
}
