// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR BSD-3-Clause

// This file does nothing, but check your Makefile to see if there is a
// reference to hello_x11.cpp - there shouldn't be if qmake is used on Windows.
