// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR BSD-3-Clause

//! [0]
void util_function_does_nothing()
{
    // Nothing here...
    int x = 0;
    ++x;
}
//! [0]

